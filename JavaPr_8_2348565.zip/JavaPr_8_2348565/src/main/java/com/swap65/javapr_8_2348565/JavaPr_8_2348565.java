/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.swap65.javapr_8_2348565;

import javax.swing.JFrame;

/**
 *
 * @author Swapnali_singh_2348565
 */
public class JavaPr_8_2348565 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Attendes Information");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Attendes attendesPanel = new Attendes();
        frame.add(attendesPanel);
        
        frame.pack();
        frame.setVisible(true);
    }
}
